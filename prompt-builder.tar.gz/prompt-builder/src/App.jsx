import { useState, useRef, useEffect, useCallback } from 'react'

const Icons = {
  Zap: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
  Copy: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>,
  Check: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
  Download: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>,
  Trash: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>,
  Clock: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
  Settings: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>,
  ChevronDown: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>,
  Sparkles: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>,
  Target: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
  List: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="8" x2="21" y1="6" y2="6"/><line x1="8" x2="21" y1="12" y2="12"/><line x1="8" x2="21" y1="18" y2="18"/><line x1="3" x2="3.01" y1="6" y2="6"/><line x1="3" x2="3.01" y1="12" y2="12"/><line x1="3" x2="3.01" y1="18" y2="18"/></svg>,
  Shield: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>,
  FileText: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>,
  Edit: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/></svg>,
  Expand: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" x2="14" y1="3" y2="10"/><line x1="3" x2="10" y1="21" y2="14"/></svg>,
}

const PROVIDERS = [
  { id: 'claude', name: 'Anthropic Claude', model: 'claude-sonnet-4-20250514', color: '#D97706' },
  { id: 'openai', name: 'OpenAI GPT-4o', model: 'gpt-4o', color: '#10A37F' },
  { id: 'gateway', name: 'Enterprise AI Gateway', model: 'custom', color: '#6366F1' },
]

const PROMPT_TEMPLATE = `You are an expert prompt engineer. Given a user's raw idea or description, transform it into a well-structured, production-grade prompt.

Return ONLY valid JSON (no markdown, no backticks) with this exact structure:
{
  "goal": "A clear, specific statement of what this prompt aims to achieve",
  "instructions": ["Step 1...", "Step 2...", "Step 3..."],
  "constraints": ["Constraint 1...", "Constraint 2..."],
  "output_format": "Description of the expected output format and structure",
  "example_usage": "A brief example of how to use this prompt",
  "system_prompt": "The complete, ready-to-use system prompt that combines all sections above into a cohesive prompt"
}

Be specific, actionable, and thorough. The system_prompt should be a complete, polished prompt ready for production use.`

function SectionCard({ icon: Icon, title, children, color, delay = 0, editable, onEdit, editing, editValue, onEditChange, onEditSave }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    const text = typeof children === 'string' ? children :
      Array.isArray(children) ? children.map((c,i)=>`${i+1}. ${c}`).join('\n') : ''
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <div style={{
      background: 'var(--bg-card)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)', padding: '20px 24px',
      animation: `fadeInUp 0.4s ease ${delay}ms both`,
      transition: 'all 200ms cubic-bezier(0.4, 0, 0.2, 1)',
      position: 'relative',
    }}
    onMouseEnter={e => { e.currentTarget.style.borderColor = color || 'var(--accent)'; e.currentTarget.style.boxShadow = 'var(--shadow-md)' }}
    onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.boxShadow = 'none' }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 'var(--radius-sm)', background: color ? `${color}12` : 'var(--accent-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon style={{ width: 16, height: 16, color: color || 'var(--accent)' }} />
          </div>
          <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: 600, fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-secondary)' }}>{title}</h3>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {editable && (
            <button onClick={onEdit} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, color: editing ? 'var(--accent)' : 'var(--text-tertiary)', transition: 'var(--transition)' }} title="Edit">
              <Icons.Edit style={{ width: 14, height: 14 }} />
            </button>
          )}
          <button onClick={handleCopy} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, color: copied ? 'var(--accent)' : 'var(--text-tertiary)', transition: 'var(--transition)' }} title="Copy">
            {copied ? <Icons.Check style={{ width: 14, height: 14 }} /> : <Icons.Copy style={{ width: 14, height: 14 }} />}
          </button>
        </div>
      </div>

      {editing ? (
        <div>
          <textarea value={editValue} onChange={e => onEditChange(e.target.value)} style={{ width: '100%', minHeight: 100, padding: 12, fontFamily: 'var(--font-body)', fontSize: '0.9rem', lineHeight: 1.7, color: 'var(--text-primary)', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', resize: 'vertical', outline: 'none' }}
            onFocus={e => e.target.style.borderColor = 'var(--accent)'} onBlur={e => e.target.style.borderColor = 'var(--border)'} />
          <button onClick={onEditSave} style={{ marginTop: 8, padding: '6px 14px', fontSize: '0.8rem', fontWeight: 600, background: 'var(--accent)', color: 'var(--text-inverse)', border: 'none', borderRadius: 'var(--radius-sm)', cursor: 'pointer' }}>Save</button>
        </div>
      ) : Array.isArray(children) ? (
        <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {children.map((item, i) => (
            <li key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', fontSize: '0.9rem', lineHeight: 1.7, color: 'var(--text-primary)', animation: `slideIn 0.3s ease ${delay + 80 * i}ms both` }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', fontWeight: 600, color: color || 'var(--accent)', background: color ? `${color}12` : 'var(--accent-muted)', borderRadius: 4, padding: '2px 6px', marginTop: 3, flexShrink: 0 }}>{String(i + 1).padStart(2, '0')}</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p style={{ fontSize: '0.9rem', lineHeight: 1.8, color: 'var(--text-primary)' }}>{children}</p>
      )}
    </div>
  )
}

function LoadingSkeleton() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {['80%', '65%', '90%', '70%'].map((w, i) => (
        <div key={i} style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '20px 24px', animation: `fadeInUp 0.3s ease ${i * 100}ms both` }}>
          <div style={{ width: 120, height: 12, borderRadius: 6, background: 'linear-gradient(90deg, var(--bg-secondary) 25%, var(--bg-hover) 50%, var(--bg-secondary) 75%)', backgroundSize: '200% 100%', animation: 'shimmer 1.5s infinite', marginBottom: 16 }} />
          <div style={{ width: w, height: 10, borderRadius: 5, background: 'linear-gradient(90deg, var(--bg-secondary) 25%, var(--bg-hover) 50%, var(--bg-secondary) 75%)', backgroundSize: '200% 100%', animation: 'shimmer 1.5s infinite' }} />
          <div style={{ width: '50%', height: 10, borderRadius: 5, marginTop: 10, background: 'linear-gradient(90deg, var(--bg-secondary) 25%, var(--bg-hover) 50%, var(--bg-secondary) 75%)', backgroundSize: '200% 100%', animation: 'shimmer 1.5s infinite' }} />
        </div>
      ))}
    </div>
  )
}

export default function App() {
  const [input, setInput] = useState('')
  const [provider, setProvider] = useState('claude')
  const [apiKey, setApiKey] = useState('')
  const [gatewayUrl, setGatewayUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [showSettings, setShowSettings] = useState(false)
  const [history, setHistory] = useState([])
  const [editingSection, setEditingSection] = useState(null)
  const [editValue, setEditValue] = useState('')
  const [showFullPrompt, setShowFullPrompt] = useState(false)
  const [copiedFull, setCopiedFull] = useState(false)
  const resultRef = useRef(null)

  useEffect(() => {
    try { const s = localStorage.getItem('prompt-builder-history'); if (s) setHistory(JSON.parse(s)) } catch {}
    try { const k = localStorage.getItem('prompt-builder-apikey'); if (k) setApiKey(k) } catch {}
    try { const p = localStorage.getItem('prompt-builder-provider'); if (p) setProvider(p) } catch {}
    try { const g = localStorage.getItem('prompt-builder-gateway'); if (g) setGatewayUrl(g) } catch {}
  }, [])

  const saveHistory = (h) => { setHistory(h); try { localStorage.setItem('prompt-builder-history', JSON.stringify(h.slice(0, 20))) } catch {} }

  useEffect(() => { try { localStorage.setItem('prompt-builder-apikey', apiKey) } catch {} }, [apiKey])
  useEffect(() => { try { localStorage.setItem('prompt-builder-provider', provider) } catch {} }, [provider])
  useEffect(() => { try { localStorage.setItem('prompt-builder-gateway', gatewayUrl) } catch {} }, [gatewayUrl])

  const callProvider = useCallback(async () => {
    if (!input.trim()) return
    if (!apiKey.trim() && provider !== 'gateway') { setError('Please add your API key in Settings (gear icon)'); setShowSettings(true); return }
    if (provider === 'gateway' && !gatewayUrl.trim()) { setError('Please add your Enterprise Gateway URL in Settings'); setShowSettings(true); return }

    setLoading(true); setError(''); setResult(null)

    try {
      let data
      if (provider === 'claude') {
        const resp = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
          body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 4096, system: PROMPT_TEMPLATE, messages: [{ role: 'user', content: `Transform this into a structured prompt:\n\n${input}` }] }),
        })
        if (!resp.ok) { const e = await resp.text(); throw new Error(`Claude API ${resp.status}: ${e.slice(0,200)}`) }
        const json = await resp.json()
        const text = json.content?.map(b => b.text || '').join('') || ''
        data = JSON.parse(text)
      } else if (provider === 'openai') {
        const resp = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
          body: JSON.stringify({ model: 'gpt-4o', response_format: { type: 'json_object' }, messages: [{ role: 'system', content: PROMPT_TEMPLATE }, { role: 'user', content: `Transform this into a structured prompt:\n\n${input}` }] }),
        })
        if (!resp.ok) { const e = await resp.text(); throw new Error(`OpenAI API ${resp.status}: ${e.slice(0,200)}`) }
        const json = await resp.json()
        data = JSON.parse(json.choices[0].message.content)
      } else if (provider === 'gateway') {
        const resp = await fetch(gatewayUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {}) },
          body: JSON.stringify({ model: 'default', messages: [{ role: 'system', content: PROMPT_TEMPLATE }, { role: 'user', content: `Transform this into a structured prompt:\n\n${input}` }] }),
        })
        if (!resp.ok) throw new Error(`Gateway error: ${resp.status}`)
        const json = await resp.json()
        const text = json.choices?.[0]?.message?.content || json.content?.map(b => b.text).join('') || ''
        data = JSON.parse(text)
      }
      setResult(data)
      saveHistory([{ id: Date.now(), input: input.slice(0, 100), result: data, provider, timestamp: new Date().toISOString() }, ...history])
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 300)
    } catch (e) {
      console.error(e)
      setError(e.message || 'Something went wrong. Check your API key and try again.')
    } finally { setLoading(false) }
  }, [input, provider, apiKey, gatewayUrl, history])

  const startEdit = (section) => { const val = result[section]; setEditValue(Array.isArray(val) ? val.join('\n') : val); setEditingSection(section) }
  const saveEdit = (section) => { const u = { ...result }; u[section] = Array.isArray(result[section]) ? editValue.split('\n').filter(l => l.trim()) : editValue; setResult(u); setEditingSection(null) }

  const copyFullPrompt = () => {
    if (!result) return
    const full = result.system_prompt || `# Goal\n${result.goal}\n\n# Instructions\n${result.instructions?.map((s,i)=>`${i+1}. ${s}`).join('\n')}\n\n# Constraints\n${result.constraints?.map(s=>`- ${s}`).join('\n')}\n\n# Output Format\n${result.output_format}`
    navigator.clipboard.writeText(full); setCopiedFull(true); setTimeout(() => setCopiedFull(false), 2000)
  }

  const exportJson = () => {
    if (!result) return
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `prompt-${Date.now()}.json`; a.click(); URL.revokeObjectURL(url)
  }

  const currentProvider = PROVIDERS.find(p => p.id === provider)

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* HEADER */}
      <header style={{ background: 'var(--bg-card)', borderBottom: '1px solid var(--border)', padding: '14px 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 100, backdropFilter: 'blur(12px)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, var(--accent) 0%, #0891B2 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--shadow-accent)' }}>
            <Icons.Sparkles style={{ width: 20, height: 20, color: '#fff' }} />
          </div>
          <div>
            <h1 style={{ fontFamily: 'var(--font-title)', fontWeight: 700, fontSize: '1.1rem', color: 'var(--text-primary)', letterSpacing: '-0.01em' }}>Prompt Builder Studio</h1>
            <p style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)', marginTop: -1 }}>Transform ideas into production-grade prompts</p>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ position: 'relative' }}>
            <select value={provider} onChange={e => setProvider(e.target.value)} style={{ appearance: 'none', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '7px 32px 7px 12px', fontSize: '0.8rem', fontWeight: 500, fontFamily: 'var(--font-body)', color: 'var(--text-primary)', cursor: 'pointer', outline: 'none' }}
              onFocus={e => e.target.style.borderColor = 'var(--accent)'} onBlur={e => e.target.style.borderColor = 'var(--border)'}>
              {PROVIDERS.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <Icons.ChevronDown style={{ width: 14, height: 14, color: 'var(--text-tertiary)', position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} />
          </div>
          <button onClick={() => setShowSettings(!showSettings)} style={{ background: showSettings ? 'var(--accent-muted)' : 'transparent', border: '1px solid transparent', borderRadius: 'var(--radius-sm)', padding: 8, cursor: 'pointer', color: showSettings ? 'var(--accent)' : 'var(--text-tertiary)' }} title="Settings">
            <Icons.Settings style={{ width: 18, height: 18 }} />
          </button>
        </div>
      </header>

      {/* SETTINGS */}
      {showSettings && (
        <div style={{ background: 'var(--bg-card)', borderBottom: '1px solid var(--border)', padding: '16px 32px', animation: 'fadeInUp 0.2s ease' }}>
          <div style={{ maxWidth: 720, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: currentProvider.color }} />
              <span style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)' }}>{currentProvider.name} Configuration</span>
            </div>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <input type="password" placeholder={`${currentProvider.name} API Key`} value={apiKey} onChange={e => setApiKey(e.target.value)}
                style={{ flex: 1, minWidth: 240, padding: '10px 14px', fontSize: '0.85rem', fontFamily: 'var(--font-mono)', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', color: 'var(--text-primary)', outline: 'none' }}
                onFocus={e => e.target.style.borderColor = 'var(--accent)'} onBlur={e => e.target.style.borderColor = 'var(--border)'} />
              {provider === 'gateway' && (
                <input type="url" placeholder="https://your-gateway.example.com/v1/chat/completions" value={gatewayUrl} onChange={e => setGatewayUrl(e.target.value)}
                  style={{ flex: 1, minWidth: 280, padding: '10px 14px', fontSize: '0.85rem', fontFamily: 'var(--font-mono)', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', color: 'var(--text-primary)', outline: 'none' }}
                  onFocus={e => e.target.style.borderColor = 'var(--accent)'} onBlur={e => e.target.style.borderColor = 'var(--border)'} />
              )}
            </div>
            <p style={{ fontSize: '0.72rem', color: 'var(--text-tertiary)' }}>Your key stays in your browser and is persisted in localStorage. Never sent anywhere except the selected provider.</p>
          </div>
        </div>
      )}

      {/* MAIN */}
      <main style={{ flex: 1, maxWidth: 820, width: '100%', margin: '0 auto', padding: '32px 24px 64px' }}>
        {/* Input */}
        <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-xl)', padding: 28, boxShadow: 'var(--shadow-sm)', marginBottom: 32 }}>
          <label style={{ display: 'block', marginBottom: 12, fontFamily: 'var(--font-title)', fontWeight: 600, fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-tertiary)' }}>
            Describe your prompt idea
          </label>
          <textarea value={input} onChange={e => setInput(e.target.value)}
            placeholder="e.g. I need a prompt that helps customer support agents draft empathetic responses to billing complaints, ensuring they acknowledge the issue, offer solutions, and maintain brand voice..."
            rows={6}
            style={{ width: '100%', padding: '16px 18px', fontSize: '0.95rem', lineHeight: 1.75, fontFamily: 'var(--font-body)', color: 'var(--text-primary)', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', resize: 'vertical', outline: 'none', transition: 'border-color 200ms' }}
            onFocus={e => e.target.style.borderColor = 'var(--accent)'} onBlur={e => e.target.style.borderColor = 'var(--border)'}
            onKeyDown={e => { if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') callProvider() }} />
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 16, flexWrap: 'wrap', gap: 12 }}>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-tertiary)' }}>
              {input.length} chars · {input.trim().split(/\s+/).filter(Boolean).length} words · {!apiKey && provider !== 'gateway' ? '⚠ API key required' : `Using ${currentProvider.name}`}
            </span>
            <div style={{ display: 'flex', gap: 8 }}>
              {input.trim() && (
                <button onClick={() => { setInput(''); setResult(null); setError('') }}
                  style={{ padding: '10px 18px', fontSize: '0.85rem', fontWeight: 500, background: 'transparent', color: 'var(--text-tertiary)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', cursor: 'pointer', fontFamily: 'var(--font-body)' }}>
                  Clear
                </button>
              )}
              <button onClick={callProvider} disabled={loading || !input.trim()}
                style={{
                  padding: '10px 24px', fontSize: '0.85rem', fontWeight: 600,
                  background: loading || !input.trim() ? 'var(--border)' : 'linear-gradient(135deg, var(--accent) 0%, #0891B2 100%)',
                  color: loading || !input.trim() ? 'var(--text-tertiary)' : 'var(--text-inverse)',
                  border: 'none', borderRadius: 'var(--radius-md)',
                  cursor: loading || !input.trim() ? 'not-allowed' : 'pointer',
                  fontFamily: 'var(--font-body)', display: 'flex', alignItems: 'center', gap: 8,
                  boxShadow: loading || !input.trim() ? 'none' : 'var(--shadow-accent)',
                }}>
                {loading ? (
                  <><span style={{ width: 16, height: 16, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.6s linear infinite', display: 'inline-block' }} />Generating...</>
                ) : (
                  <><Icons.Zap style={{ width: 16, height: 16 }} />Generate Prompt</>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Error */}
        {error && <div style={{ background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 'var(--radius-md)', padding: '14px 20px', marginBottom: 24, fontSize: '0.85rem', color: '#991B1B', animation: 'fadeInUp 0.3s ease' }}>{error}</div>}

        {/* Loading */}
        {loading && <LoadingSkeleton />}

        {/* Results */}
        {result && !loading && (
          <div ref={resultRef} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)', marginBottom: 4 }}>
              <h2 style={{ fontFamily: 'var(--font-title)', fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: 8 }}>
                <Icons.Sparkles style={{ width: 18, height: 18, color: 'var(--accent)' }} />Generated Prompt
              </h2>
              <div style={{ display: 'flex', gap: 6 }}>
                <button onClick={copyFullPrompt} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', fontSize: '0.78rem', fontWeight: 600, fontFamily: 'var(--font-body)', background: copiedFull ? 'var(--accent-muted)' : 'var(--bg-secondary)', color: copiedFull ? 'var(--accent)' : 'var(--text-secondary)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', cursor: 'pointer' }}>
                  {copiedFull ? <Icons.Check style={{ width: 13, height: 13 }} /> : <Icons.Copy style={{ width: 13, height: 13 }} />}
                  {copiedFull ? 'Copied!' : 'Copy Full Prompt'}
                </button>
                <button onClick={exportJson} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', fontSize: '0.78rem', fontWeight: 600, fontFamily: 'var(--font-body)', background: 'var(--bg-secondary)', color: 'var(--text-secondary)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', cursor: 'pointer' }}>
                  <Icons.Download style={{ width: 13, height: 13 }} />Export JSON
                </button>
              </div>
            </div>

            <SectionCard icon={Icons.Target} title="Goal" color="#0D9488" delay={0} editable onEdit={() => startEdit('goal')} editing={editingSection === 'goal'} editValue={editValue} onEditChange={setEditValue} onEditSave={() => saveEdit('goal')}>{result.goal}</SectionCard>
            <SectionCard icon={Icons.List} title="Instructions" color="#2563EB" delay={80} editable onEdit={() => startEdit('instructions')} editing={editingSection === 'instructions'} editValue={editValue} onEditChange={setEditValue} onEditSave={() => saveEdit('instructions')}>{result.instructions}</SectionCard>
            <SectionCard icon={Icons.Shield} title="Constraints" color="#D97706" delay={160} editable onEdit={() => startEdit('constraints')} editing={editingSection === 'constraints'} editValue={editValue} onEditChange={setEditValue} onEditSave={() => saveEdit('constraints')}>{result.constraints}</SectionCard>
            <SectionCard icon={Icons.FileText} title="Output Format" color="#7C3AED" delay={240} editable onEdit={() => startEdit('output_format')} editing={editingSection === 'output_format'} editValue={editValue} onEditChange={setEditValue} onEditSave={() => saveEdit('output_format')}>{result.output_format}</SectionCard>
            {result.example_usage && <SectionCard icon={Icons.Zap} title="Example Usage" color="#059669" delay={320}>{result.example_usage}</SectionCard>}

            {/* Full System Prompt */}
            {result.system_prompt && (
              <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', animation: 'fadeInUp 0.4s ease 400ms both' }}>
                <button onClick={() => setShowFullPrompt(!showFullPrompt)} style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 24px', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--font-body)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 32, height: 32, borderRadius: 'var(--radius-sm)', background: '#F0FDF4', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Icons.Expand style={{ width: 16, height: 16, color: '#16A34A' }} />
                    </div>
                    <span style={{ fontFamily: 'var(--font-title)', fontWeight: 600, fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-secondary)' }}>Complete System Prompt</span>
                  </div>
                  <Icons.ChevronDown style={{ width: 16, height: 16, color: 'var(--text-tertiary)', transition: '200ms', transform: showFullPrompt ? 'rotate(180deg)' : 'rotate(0)' }} />
                </button>
                {showFullPrompt && (
                  <div style={{ padding: '0 24px 20px' }}>
                    <pre style={{ fontFamily: 'var(--font-mono)', fontSize: '0.82rem', lineHeight: 1.8, color: 'var(--text-primary)', background: 'var(--bg-code)', padding: 20, borderRadius: 'var(--radius-md)', border: '1px solid var(--border)', whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 500, overflow: 'auto' }}>
                      {result.system_prompt}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* History */}
        {history.length > 0 && !loading && (
          <div style={{ marginTop: 48 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: 600, fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-tertiary)', display: 'flex', alignItems: 'center', gap: 8 }}>
                <Icons.Clock style={{ width: 14, height: 14 }} />Recent Prompts
              </h3>
              <button onClick={() => saveHistory([])} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.72rem', color: 'var(--text-tertiary)', fontFamily: 'var(--font-body)', display: 'flex', alignItems: 'center', gap: 4 }}>
                <Icons.Trash style={{ width: 12, height: 12 }} /> Clear history
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {history.slice(0, 5).map((item, i) => (
                <button key={item.id} onClick={() => { setInput(item.input); setResult(item.result) }}
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '12px 18px', cursor: 'pointer', textAlign: 'left', fontFamily: 'var(--font-body)', animation: `fadeInUp 0.3s ease ${i * 60}ms both`, transition: '200ms' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.background = 'var(--bg-hover)' }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--bg-card)' }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-primary)', fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.input}</p>
                    <p style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)', marginTop: 2 }}>{new Date(item.timestamp).toLocaleDateString()} · {PROVIDERS.find(p => p.id === item.provider)?.name}</p>
                  </div>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', flexShrink: 0, marginLeft: 12, background: PROVIDERS.find(p => p.id === item.provider)?.color || 'var(--text-tertiary)' }} />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {!result && !loading && !error && (
          <div style={{ textAlign: 'center', padding: '48px 24px', animation: 'fadeInUp 0.5s ease 200ms both' }}>
            <div style={{ width: 64, height: 64, borderRadius: 'var(--radius-xl)', background: 'var(--accent-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px' }}>
              <Icons.Sparkles style={{ width: 28, height: 28, color: 'var(--accent)' }} />
            </div>
            <h3 style={{ fontFamily: 'var(--font-title)', fontWeight: 700, fontSize: '1.1rem', color: 'var(--text-primary)', marginBottom: 8 }}>Describe what you need</h3>
            <p style={{ fontSize: '0.88rem', color: 'var(--text-tertiary)', maxWidth: 420, margin: '0 auto', lineHeight: 1.7 }}>
              Enter your rough idea above and we'll transform it into a structured, production-ready prompt with goal, instructions, constraints, and output format.
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, justifyContent: 'center', marginTop: 28 }}>
              {['Customer support response agent', 'Code review assistant', 'Meeting notes summarizer', 'SQL query generator'].map((example, i) => (
                <button key={i} onClick={() => setInput(example)}
                  style={{ padding: '8px 16px', fontSize: '0.8rem', fontWeight: 500, background: 'var(--bg-card)', color: 'var(--text-secondary)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', cursor: 'pointer', fontFamily: 'var(--font-body)', transition: '200ms', animation: `fadeInUp 0.4s ease ${400 + i * 80}ms both` }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)' }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-secondary)' }}>
                  {example}
                </button>
              ))}
            </div>
          </div>
        )}
      </main>

      <footer style={{ borderTop: '1px solid var(--border)', padding: '14px 32px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ fontSize: '0.7rem', color: 'var(--text-tertiary)' }}>Prompt Builder Studio · React + Vite · Ctrl+Enter to generate</p>
      </footer>
    </div>
  )
}
